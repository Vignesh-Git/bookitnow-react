import React from "react";

function ReferCentre() {
  return <div className="container mx-auto">asdk</div>;
}

export default ReferCentre;
