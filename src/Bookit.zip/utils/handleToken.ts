// const setTokenToCookie = (token : string) => {
//     document.cookie += ` = ${}`
// }